# Cifrário — app Android (offline)

Projeto do app Cifrário (cifras, repertório e setlists). Funciona sem internet:
tudo fica salvo no próprio aparelho. Setlists são compartilhadas como arquivo (.json).

O APK é gerado automaticamente pelo GitHub Actions (arquivo .github/workflows/gerar-apk.yml).
Para atualizar o app: troque o zip do projeto no repositório; uma nova versão é publicada
em "Releases" e instala por cima da anterior (mesma chave de assinatura).

Estrutura:
- www/            app (HTML/JS), leitor de PDF e fontes embutidos
- android/        projeto Android (Capacitor 6)
- capacitor.config.json, package.json
